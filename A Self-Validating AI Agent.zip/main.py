from ai_agent import AIAgent
from validation import Validator
import json

# Load mock customer feedback
with open("data_feedback.json", "r") as file:
    feedback_data = json.load(file)

# Initialize AI agent and validator
agent = AIAgent()
validator = Validator()

# Generate summary
summary = agent.generate_summary(feedback_data)
print("Generated Summary:", summary)

# Validate summary
validation_results = validator.validate(feedback_data, summary)
print("Validation Results:", validation_results)

# Feedback loop (mock implementation)
if validation_results["accuracy"] < 0.8 or validation_results["relevance"] < 0.8:
    print("Summary flagged for review.")
else:
    print("Summary approved.")