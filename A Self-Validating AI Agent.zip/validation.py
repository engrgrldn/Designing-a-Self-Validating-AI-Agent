from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import spacy

class Validator:
    def __init__(self):
        self.vectorizer = CountVectorizer()
        self.nlp = spacy.load("en_core_web_sm")

    def validate(self, feedback, summary):
        # Accuracy: Semantic similarity
        feedback_vector = self.vectorizer.fit_transform(feedback).toarray()
        summary_vector = self.vectorizer.transform([summary]).toarray()
        accuracy = cosine_similarity(feedback_vector, summary_vector).mean()

        # Relevance: Keyword matching
        keywords = ["delivery", "performance", "delay", "on time"]
        relevance = sum(1 for word in summary.split() if word in keywords) / len(summary.split())

        # Consistency: Simple contradiction detection (mock implementation)
        doc = self.nlp(summary)
        contradictions = [sent for sent in doc.sents if "not" in sent.text]
        consistency = 1 - len(contradictions) / len(list(doc.sents))

        return {
            "accuracy": accuracy,
            "relevance": relevance,
            "consistency": consistency
        }