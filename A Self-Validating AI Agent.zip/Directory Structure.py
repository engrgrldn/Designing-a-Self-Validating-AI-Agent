self_validating_ai/
├── main.py               # Main script
├── validation.py         # Validation logic
├── ai_agent.py           # AI agent logic
├── data/
│   ├── feedback.json     # Mock customer feedback
│   └── stopwords.txt     # Stopwords for keyword extraction
├── README.md             # Documentation