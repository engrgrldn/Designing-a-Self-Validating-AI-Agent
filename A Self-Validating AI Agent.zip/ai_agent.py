from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class AIAgent:
    def __init__(self):
        self.vectorizer = CountVectorizer()

    def generate_summary(self, feedback):
        # Simple summary generation by extracting key themes
        themes = [review for review in feedback if "delivery" in review or "performance" in review]
        return " ".join(themes)